PackageHandlers.registerClientHandler("OpenPlayerAttrUI",function(player)
    UI:openWindow("playerattr")
end)