PackageHandlers.registerClientHandler("OpenLevelUI",function(player)
    UI:openWindow("level")
end)