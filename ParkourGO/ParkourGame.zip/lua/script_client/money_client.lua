PackageHandlers.registerClientHandler("OpenMoneyUI",function(player)
    UI:openWindow("money")
end)