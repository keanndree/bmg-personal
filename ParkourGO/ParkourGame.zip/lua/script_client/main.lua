print('script_client:hello world')

require "script_client.backpack_client"
require "script_client.secondjump_client"
require "script_client.upgrade_client"
--require "script_client.money_client"
--require "script_client.level_client"
require "script_client.playerattr_client"
require "script_client.gameplay_client"
------------------------------------------------------------------------------------

UI:openWindow("outroombtn")
UI:openWindow("mainmenu")