local okbtn = self:child("OKBtn")
okbtn.onMouseClick = function()
  UI:closeWindow("losenotification")
end